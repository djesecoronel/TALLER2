package taller.pkg2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */

import java.util.Scanner;

/**
 *
 * @author coronel
 */

public class Punto1 {
    
    public static void main(String[] args) { 
        int x = 16;
        
        System.out.printf("x = %d\n",x );
        System.out.printf("El valor de %d + %d es %d\n",x,x,(x + x) );
        System.out.printf("El valor de %d / 2 = %.2f\n",x,(float)(x/2));
        System.out.printf("El valor de %d mod 3 = %d\n",x,x%3 );

    }
}
